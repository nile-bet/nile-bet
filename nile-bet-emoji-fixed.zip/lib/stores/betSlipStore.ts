import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { useAuthStore } from '@/lib/stores/authStore'
import {
  calculateSlip,
  getValidationErrors,
} from '@/lib/utils/calculateSlip'

function getTaxRate(): number {
  try {
    const s = useAuthStore.getState().settings
    return s?.winningTaxPercent ?? 15
  } catch { return 15 }
}
import type {
  BetSlipSelection,
  SlipCalculation,
  PlatformSettings,
} from '@/types/database.types'

interface BetSlipState {
  selections: BetSlipSelection[]
  stake: number
  calculation: SlipCalculation
  copiedFromSlipId: string | null
  selectedBettorId: string | null
  selectedBettorName: string | null
  isAnonymous: boolean
  isJackpot: boolean
  addSelection: (
    s: BetSlipSelection
  ) => void
  removeSelection: (
    matchMarketId: string,
    selection: string
  ) => void
  setStake: (amount: number) => void
  clearSlip: () => void
  setSelectedBettor: (
    id: string,
    name: string
  ) => void
  setAnonymous: (v: boolean) => void
  setCopiedFrom: (
    slipId: string | null
  ) => void
  calculateSlipTotals: () => void
  isSelectionAdded: (
    matchMarketId: string,
    selection: string
  ) => boolean
  getValidationErrors: (settings: PlatformSettings) => string[]
  removeStartedSelections: () => void
  hasHydrated: boolean
  setHasHydrated: (v: boolean) => void
}

const emptyCalc: SlipCalculation = {
  stake: 0,
  totalOdds: 0,
  maxPayout: 0,
  winningTax: 0,
  netPayout: 0,
}

export const useBetSlipStore =
  create<BetSlipState>()(
  persist(
    (set, get) => ({
    selections: [],
    stake: 0,
    calculation: emptyCalc,
    copiedFromSlipId: null,
    selectedBettorId: null,
    selectedBettorName: null,
    isAnonymous: false,
    isJackpot: false,
    hasHydrated: false,
    setHasHydrated: (v) => set({ hasHydrated: v }),

    addSelection: (s) => {
      const existing = get().selections
      // Remove if same match — only 1 selection per match allowed
      const filtered = existing.filter(
        (sel) =>
          sel.matchId !==
          s.matchId
      )
      const newSelections = [...filtered, s]
      const calc = calculateSlip(
        get().stake, newSelections.map((sel) => sel.odd), getTaxRate()
      )
      set({
        selections: newSelections,
        calculation: calc,
      })
    },

    removeSelection: (
      matchMarketId,
      selection
    ) => {
      const newSelections =
        get().selections.filter(
          (s) =>
            !(
              s.matchMarketId ===
                matchMarketId &&
              s.selection === selection
            )
        )
      const calc = calculateSlip(
        get().stake, newSelections.map((s) => s.odd), getTaxRate()
      )
      set({
        selections: newSelections,
        calculation: calc,
      })
    },

    setStake: (amount) => {
      const calc = calculateSlip(
        amount, get().selections.map((s) => s.odd), getTaxRate()
      )
      set({ stake: amount, calculation: calc })
    },

    clearSlip: () =>
      set({
        selections: [],
        stake: 0,
        calculation: emptyCalc,
        copiedFromSlipId: null,
        selectedBettorId: null,
        selectedBettorName: null,
        isAnonymous: false,
        isJackpot: false,
      }),

    setSelectedBettor: (id, name) =>
      set({
        selectedBettorId: id,
        selectedBettorName: name,
        isAnonymous: false,
      }),

    setAnonymous: (v) =>
      set({
        isAnonymous: v,
        selectedBettorId: v ? null :
          get().selectedBettorId,
        selectedBettorName: v ? null :
          get().selectedBettorName,
      }),

    setCopiedFrom: (slipId) =>
      set({ copiedFromSlipId: slipId }),

    calculateSlipTotals: () => {
      const calc = calculateSlip(
        get().stake, get().selections.map((s) => s.odd), getTaxRate()
      )
      set({ calculation: calc })
    },

    isSelectionAdded: (
      matchMarketId,
      selection
    ) =>
      get().selections.some(
        (s) =>
          s.matchMarketId ===
            matchMarketId &&
          s.selection === selection
      ),

    removeStartedSelections: () => {
      const newSelections = get().selections.filter(
        (s) => s.matchStatus !== 'closed' && s.matchStatus !== 'finished'
      )
      const calc = calculateSlip(get().stake, newSelections.map((s) => s.odd), getTaxRate())
      set({ selections: newSelections, calculation: calc })
    },

    hasStartedMatches: () =>
      get().selections.some(
        (s) =>
          s.matchStatus === 'closed' ||
          s.matchStatus === 'finished'
      ),

    getValidationErrors: (settings) =>
      getValidationErrors(
        get().stake,
        get().selections,
        settings
      ),
    }),
    {
      name: 'nilebet-betslip',
      storage: createJSONStorage(() => sessionStorage),
      partialize: (state) => ({
        selections: state.selections,
        stake: state.stake,
        calculation: state.calculation,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true)
      },
    }
  )
)